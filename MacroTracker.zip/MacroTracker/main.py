from kivy.app import App
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.gridlayout import GridLayout


import pickle as pk
from datetime import datetime, timedelta
import os




class Food:
    def __init__(self, name, calories, carbs, fats, protein):
        self.food_name = name
        self.food_calories = calories
        self.food_carbs = carbs
        self.food_fats = fats
        self.food_protein = protein
        
        
class MacroTrack(App):
    
    
    title = "Macro Tracker"
    def build(self):
        main = BoxLayout(orientation="vertical", padding=20, spacing=10)

        

        row1 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        
        

        row2 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        row2.add_widget(Label(text="Calories Left:", size_hint=(.3, 1)))
        self.lbl_cal_left=(Label(text="0", size_hint=(.3, 1)))
        row2.add_widget(self.lbl_cal_left)
        self.txt_cal_left=(TextInput(size_hint=(.4, 1)))
        row2.add_widget(self.txt_cal_left)
        main.add_widget(row2)

        row3 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        row3.add_widget(Label(text="Carbs Left:", size_hint=(.3, 1)))
        self.lbl_carb_left=(Label(text="0", size_hint=(.3, 1)))
        row3.add_widget(self.lbl_carb_left)
        self.txt_carb_left=(TextInput(size_hint=(.4, 1)))
        row3.add_widget(self.txt_carb_left)
        main.add_widget(row3)

        row4 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        row4.add_widget(Label(text="Fats Left:", size_hint=(.3, 1)))
        self.lbl_fat_left=(Label(text="0", size_hint=(.3, 1)))
        row4.add_widget(self.lbl_fat_left)
        self.txt_fat_left=(TextInput(size_hint=(.4, 1)))
        row4.add_widget(self.txt_fat_left)
        main.add_widget(row4)

        row5 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        row5.add_widget(Label(text="Protein Left:", size_hint=(.3, 1)))
        self.lbl_pro_left=(Label(text="0", size_hint=(.3, 1)))
        row5.add_widget(self.lbl_pro_left)
        self.txt_pro_left=(TextInput(size_hint=(.4, 1)))
        row5.add_widget(self.txt_pro_left)
        main.add_widget(row5)

        row6 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        row6.add_widget(Label(text="Servings:", size_hint=(.3, 1)))
        row6.add_widget(Label(text="", size_hint=(.3, 1)))
        self.txt_servings = (TextInput(text="1", size_hint=(.4, 1)))
        row6.add_widget(self.txt_servings)
        main.add_widget(row6)
                        

        row7 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        self.btn_add=(Button(text="Add Meal", size_hint=(.20, 1)))
        row7.add_widget(self.btn_add)
        self.btn_add.bind(on_press=self.add_entry)
        self.btn_set=(Button(text="Set Total", size_hint=(.20, 1)))
        row7.add_widget(self.btn_set)
        self.btn_set.bind(on_press=self.pop_up)
        self.btn_saveFood = (Button(text="Save Food", size_hint=(.20, 1)))
        row7.add_widget(self.btn_saveFood)
        self.btn_saveFood.bind(on_press=self.pop_up_add_meal)
        self.btn_set.bind(on_press=self.pop_up)
        self.btn_deleteFood = (Button(text="Delete Food", size_hint=(.20, 1)))
        row7.add_widget(self.btn_deleteFood)
        self.btn_deleteFood.bind(on_press=self.popup_delete)
        self.btn_viewWeek = (Button(text="View Week", size_hint=(.20, 1)))
        row7.add_widget(self.btn_viewWeek)
        self.btn_viewWeek.bind(on_press=self.popup_savedWeek)
        

        
        main.add_widget(row7)

        rowSpc2 = BoxLayout(orientation="horizontal", spacing=10, size_hint=(1, .05))
        main.add_widget(rowSpc2)

        scroll_layout = GridLayout(cols=1, spacing=5, size_hint_y=None)
        scroll_layout.bind(minimum_height=scroll_layout.setter("height"))
        scroll_view = ScrollView(size_hint=(1, .25))
        scroll_view.add_widget(scroll_layout)
        main.add_widget(scroll_view)

        self.food_list_layout = scroll_layout
        
        self.trackDay = datetime.now()
        self.dateStr = datetime.now().strftime("%m-%d-%Y")       

        self.firstDay = self.trackDay        
        self.curDate = self.dateStr
        
        self.savedData = {}
        self.savedFoods={}
        self.savedDay = {}
        
        self.open_data()
        self.update_food_list()
        print(self.savedDay)

        
        
        return main
    def popup_savedWeek(self, instance):
        if not self.savedDay:
            # No saved data
            popup = Popup(title="No Data", 
                     content=Label(text="No saved days yet!"),
                     size_hint=(.6, .4))
            popup.open()
            return
        date_list = list(self.savedDay.keys())
        self.current_index = 0
        
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        
        lbl_date = Label(text="", size_hint_y=.1)
        layout.add_widget(lbl_date)
    
        lbl_cal = Label(text="", size_hint_y=.1)
        layout.add_widget(lbl_cal)
    
        lbl_carb = Label(text="", size_hint_y=.1)
        layout.add_widget(lbl_carb)
    
        lbl_fat = Label(text="", size_hint_y=.1)
        layout.add_widget(lbl_fat)
    
        lbl_pro = Label(text="", size_hint_y=.1)
        layout.add_widget(lbl_pro)
        
        def update_display():
            date = date_list[self.current_index]
            data = self.savedDay[date]
            lbl_date.text = f"Date: {date}"
            lbl_cal.text = f"Calories: {data.get('Calorie', 0)}"
            lbl_carb.text = f"Carbs: {data.get('Carb', 0)}"
            lbl_fat.text = f"Fats: {data.get('Fat', 0)}"
            lbl_pro.text = f"Protein: {data.get('Protein', 0)}"
        def go_forward(instance):
            if self.current_index < len(date_list) - 1:
                self.current_index += 1
                update_display()
    
        def go_backward(instance):
            if self.current_index > 0:
                self.current_index -= 1
                update_display()
        buttons = BoxLayout(orientation="horizontal", size_hint=(1, .3))
        
        btn_backward = Button(text="Previous Day", size_hint_y=.8)
        btn_backward.bind(on_press=go_backward)
        buttons.add_widget(btn_backward)
    
        btn_forward = Button(text="Next Day", size_hint_y=.8)
        btn_forward.bind(on_press=go_forward)
        buttons.add_widget(btn_forward)
        layout.add_widget(buttons)

        update_display()

        

        popup = Popup(title="Weekly Review", content=layout, size_hint=(.8, .5))

        

        popup.open()

   
        

        
    def popup_delete(self, instance):
        layout = GridLayout(cols=1, spacing=5, size_hint_y=None, padding=10)
        layout.bind(minimum_height=layout.setter("height"))
        layout_view=ScrollView(size_hint=(1, 1))
        layout_view.add_widget(layout)
        popup = Popup(title="Delete Food", content=layout_view, size_hint=(.8, .8))

        for food_name in self.savedFoods.keys():
            btn = Button(
                text=f"Delete {food_name}",
                size_hint_y=None,
                height=60)
            btn.bind(on_press=lambda x, name=food_name, p=popup: self.delete_food(name, p))
            layout.add_widget(btn)

        

        popup.open()

    def delete_food(self, food_name, popup):
        del self.savedFoods[food_name]

        self.savedData["foods"] = self.savedFoods
        self.save_data()

        self.update_food_list()

        popup.dismiss()
        
    def save_meal(self, name, cal, carb, fat, pro, popup_meal):        
        try:
            cals = int(cal)
            carbs= int(carb)
            fats = int(fat)
            pros = int(pro)
        except:
            return
        
        new_food=Food(name, cals, carbs, fats, pros)
        self.savedFoods[name] = new_food
        self.savedData["foods"] = self.savedFoods
        self.save_data()
        self.update_food_list()
        popup_meal.dismiss()

    def update_food_list(self):
        self.food_list_layout.clear_widgets()

        for food_name, food_obj in self.savedFoods.items():
            btn = Button(
                text=f"{food_name}",
                size_hint_y=None,
                height=50)
            btn.bind(on_press=lambda x, name=food_name: self.select_food(name))
            self.food_list_layout.add_widget(btn)
            
    def select_food(self, food_name):
        food = self.savedFoods[food_name]
        self.txt_cal_left.text = str(food.food_calories)
        self.txt_carb_left.text = str(food.food_carbs)
        self.txt_fat_left.text = str(food.food_fats)
        self.txt_pro_left.text = str(food.food_protein)

    def pop_up_add_meal(self, instance):
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)

        food_name = TextInput(hint_text="Food Name", multiline=False)
        layout.add_widget(food_name)

        food_calories = TextInput(hint_text="Calories", multiline = False)
        layout.add_widget(food_calories)

        food_carbs = TextInput(hint_text="Carbs", multiline = False)
        layout.add_widget(food_carbs)

        food_fat = TextInput(hint_text="Fats", multiline = False)
        layout.add_widget(food_fat)

        food_pro = TextInput(hint_text="Proteins", multiline = False)
        layout.add_widget(food_pro)

        save_btn=Button(text="Save", size_hint_y=(.5))
        layout.add_widget(save_btn)

        popup_meal = Popup(title="Save food", content=layout, size_hint=(.8, .8))

        save_btn.bind(on_press= lambda x: self.save_meal(food_name.text, food_calories.text, food_carbs.text,
                                                          food_fat.text, food_pro.text, popup_meal))
        popup_meal.open()
                      
        
    def pop_up(self, instance):
        layout = BoxLayout(orientation="vertical", padding=10, spacing=10)
        
        text_input=TextInput(hint_text="Total Calories", multiline = False)
        layout.add_widget(text_input)

        submit_btn = Button(text="Sumbit", size_hint_y=.3)
        layout.add_widget(submit_btn)

        popup = Popup(title="Set Total", content=layout, size_hint=(.8, .5))

        submit_btn.bind(on_press= lambda x: self.set_total(text_input.text, popup))

        popup.open()

    def set_total(self, data, popup):
        try:
            tot_calories = int(data)
            tot_carb = round((tot_calories * .4)/4)
            tot_fat = round((tot_calories*.3)/9)
            tot_pro = round((tot_calories*.3)/4)
            self.lbl_cal_left.text=str(tot_calories)
            self.lbl_carb_left.text=str(tot_carb)
            self.lbl_fat_left.text=str(tot_fat)
            self.lbl_pro_left.text=str(tot_pro)

            self.savedData = {
                "firstDay": self.savedData.get("firstDay",self.firstDay),
                "foods":self.savedFoods,
                "total":tot_calories,
                "date": self.curDate,
                "Calorie": int(self.lbl_cal_left.text),
                "Carb": int(self.lbl_carb_left.text),
                "Fat": int(self.lbl_fat_left.text),
                "Protein": int(self.lbl_pro_left.text)
                }
            self.save_data()
            popup.dismiss()
        except:
            return

    def add_entry(self, instance):
        try:
            calorie = int(self.txt_cal_left.text)
            carb = int(self.txt_carb_left.text)
            fat = int(self.txt_fat_left.text)
            protein = int(self.txt_pro_left.text)

            cal_tot = int(self.lbl_cal_left.text)
            carb_tot = int(self.lbl_carb_left.text)
            fat_tot = int(self.lbl_fat_left.text)
            pro_tot = int(self.lbl_pro_left.text)
            serving = int(self.txt_servings.text)
        except:
            return
        
        if serving > 1:
            cal_tot -= (calorie * serving)
            carb_tot -= (carb * serving)
            fat_tot -= (fat * serving)
            pro_tot -= (protein * serving)
        else:
            cal_tot -= calorie
            carb_tot -= carb
            fat_tot -= fat
            pro_tot -= protein

        self.savedData["Calorie"] = cal_tot
        self.savedData["Carb"] = carb_tot
        self.savedData["Fat"] = fat_tot
        self.savedData["Protein"] = pro_tot

        self.lbl_cal_left.text=str(cal_tot)
        self.lbl_carb_left.text=str(carb_tot)
        self.lbl_fat_left.text=str(fat_tot)
        self.lbl_pro_left.text=str(pro_tot)

        self.txt_cal_left.text=""
        self.txt_carb_left.text=""
        self.txt_fat_left.text=""
        self.txt_pro_left.text=""

        self.save_data()

    def save_data(self):
        try:
            data_path = self.get_data_path()
            with open(data_path, "wb") as file:
                pk.dump((self.savedData, self.savedDay), file)
        except Exception as e:
            print(f"Error saving: {e}")

    def get_data_path(self):
        """Get the correct path for saving data on Android"""
        # Use app's user_data_dir which works on both desktop and Android
        return os.path.join(self.user_data_dir, "data.pkl")

    def open_data(self):
        try:
            data_path = self.get_data_path()
            
            with open(data_path, "rb") as file:
                data, savedDay = pk.load(file)                
                self.savedDay = savedDay
                savedDate = data.get("date", "")               
                total_cal = data.get("total", 0)
                self.savedFoods = data.get("foods", {})
                self.firstDay = data.get("firstDay", self.trackDay)

                                
                        
                if savedDate == self.curDate:
                    
                    self.lbl_cal_left.text=str(data["Calorie"])
                    self.lbl_carb_left.text=str(data["Carb"])
                    self.lbl_fat_left.text=str(data["Fat"])
                    self.lbl_pro_left.text=str(data["Protein"])
                    self.savedData = data
                else:
                    if savedDate:
                        self.savedDay[savedDate] = data
                    if self.firstDay + timedelta(weeks=1) <= self.trackDay:
                        self.savedDay = {}
                        self.firstDay = self.trackDay
                    tot_carbs = round((total_cal * .4) / 4)
                    tot_fats = round((total_cal * .3) / 9)
                    tot_pro = round((total_cal * .3) / 4)

                    self.lbl_cal_left.text=str(total_cal)
                    self.lbl_carb_left.text=str(tot_carbs)
                    self.lbl_fat_left.text=str(tot_fats)
                    self.lbl_pro_left.text=str(tot_pro)

                    self.savedData = {
                        "firstDay": self.firstDay,
                        "foods": self.savedFoods,
                        "total": total_cal,
                        "date": self.curDate,  
                        "Calorie": total_cal,
                        "Carb": tot_carbs,
                        "Fat": tot_fats,
                        "Protein": tot_pro
                    }
                    self.save_data()   

        except (FileNotFoundError, Exception) as e:
            print(f"No saved data: {e}")
            
                                               
    

if __name__ == "__main__":
    MacroTrack().run()
        
