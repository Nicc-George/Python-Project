import tkinter as tk
from tkinter import messagebox
import User as us
import pickle as pk

class LoginPage:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Login/Register")
        self.root.geometry("200x100")

        self.root.rowconfigure(0, minsize=25)
        self.root.rowconfigure(1, minsize=25)
        self.root.rowconfigure(2, minsize=25)
        self.root.columnconfigure(0, minsize=25)
        self.root.columnconfigure(1, minsize=25)

        self.login_manager = us.Login_Page()
        
        userLbl = tk.Label(self.root, text="Username:")
        userLbl.grid(row=0, column=0)
        
        self.userEntry = tk.Entry(self.root, width=15)
        self.userEntry.grid(row=0, column=1)
        
        passwrdLbl = tk.Label(self.root, text="Password:")
        passwrdLbl.grid(row=1, column=0)

        self.passwrdEntry = tk.Entry(self.root, show="*", width=15)
        self.passwrdEntry.grid(row=1, column=1)
        
        btnLogin = tk.Button(self.root, text="Login", command=self.handle_login)
        btnLogin.grid(row=2, column=0)
        btnRegister = tk.Button(self.root, text="Register", command=self.register_page_click)
        btnRegister.grid(row=2, column=1)

       
        
        

    def handle_login(self):
        user = self.userEntry.get()
        password = self.passwrdEntry.get()
        message, result = self.login_manager.login_click(user, password)
        if result != True:
            messagebox.showinfo("Login Failed", message)
        else:
            self.root.destroy()
            Main_Page(user)
        
    def register_page_click(self):
        self.root.withdraw()
        Register_Page(self.login_manager, self.root)
    def run(self):
        self.root.mainloop()
        
class Main_Page:
    def __init__(self, user):
        self.main = tk.Tk()
        self.main.title(f"WELCOME {user}")
        self.main.geometry("450x450")
        self.main.rowconfigure(0, weight=1)
        self.main.columnconfigure(0, weight=1)
        nukeBtn = tk.Button(text="Nuke", command=self.nuke)
        nukeBtn.grid(row=0, column = 0, sticky="NSEW")
    def nuke(self):
        messagebox.showinfo("NUKED", "The world is now gone")
            
        
        self.main.mainloop()
        
class Register_Page:
    def __init__(self, login_manager, root):
        self.login_manager = login_manager
        self.root = root
        self.reg = tk.Toplevel(root)
        self.reg.title("Register")
        self.reg.geometry("250x250")
        self.reg.rowconfigure(0, minsize=25)
        self.reg.rowconfigure(1, minsize=25)
        self.reg.rowconfigure(2, minsize=25)
        self.reg.columnconfigure(0, minsize=25)
        self.reg.columnconfigure(1, minsize=25)

        userRegLabel = tk.Label(self.reg, text="New Username")
        userRegLabel.grid(row=0, column=0)

        passWrdLabel = tk.Label(self.reg, text="New Password")
        passWrdLabel.grid(row=1, column=0)

        self.userRegEntry = tk.Entry(self.reg, width=15)
        self.userRegEntry.grid(row=0, column=1)

        self.passWrdEntry = tk.Entry(self.reg,show="*", width=15)
        self.passWrdEntry.grid(row=1, column=1)

        btnReg = tk.Button(self.reg, text="Register", command=self.handle_register)
        btnReg.grid(row=2, column=0, columnspan=2)

    def handle_register(self):
        user = self.userRegEntry.get()
        password = self.passWrdEntry.get()
        message, result = self.login_manager.register_click(user, password)
        if result != True:
            messagebox.showinfo("Error", message)
        else:
            self.reg.destroy()
            self.root.deiconify()

     
                
    
            
if __name__ == "__main__":
    app = LoginPage()
    app.run()
    
