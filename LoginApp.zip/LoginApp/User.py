import pickle as pk
class User:
    def __init__(self, login, password):
        self._login = login
        self._password = password

    def get_login(self):
        return self._login

    def password_check(self, password):
        if self._password == password:
            return True
        else:
            return False

class User_Manager:
    def __init__(self):
        self.usernames = {}
        self.load_user()

    def save_user(self):
        with open("users.pkl", "wb") as file:
            pk.dump(self.usernames, file)
            
    def load_user(self):
        try:
            with open("users.pkl", "rb") as file:
                self.usernames = pk.load(file)
        except FileNotFoundError:
            self.usernames = {}
    
    def register(self, user, password):       
        if user in self.usernames:
            return f"{user} is already taken", False
        self.usernames[user] = User(user, password)
        self.save_user()
        return f"Registered", True

    def login(self, user, password):
        if user not in self.usernames:
            return f"{user} not found.", False
        current_user = self.usernames[user]
        if current_user.password_check(password):
            return f"Login Successful", True
        else:
            return f"Incorrect password.", False

class Login_Page:
    def __init__(self):
        self.user_manager = User_Manager()
    def login_click(self, user, password):
        result = self.user_manager.login(user, password)
        return result
    def register_click(self, user, password):
        result = self.user_manager.register(user, password)
        return result
        
    
